const imgfruit1 = document.getElementById("a1");
const imgfruit2 = document.getElementById("a2");
const imgfruit3 = document.getElementById("a3");
const btnSpin = document.getElementById("spin");
const btnCollectWinnings = document.getElementById("collectwinnings");
const txtcredit = document.getElementById("credit");
const txtwinnings = document.getElementById("Winnings");
const button1 = document.getElementById("button1")

btnSpin.addEventListener("click", spin);
btnCollectWinnings.addEventListener("click", collectwinnings);
button1.addEventListener("click", buttonClick)

var i = 0;
var x = 0;

function buttonClick() {
    i++;
    document.getElementById('credit').innerHTML = i;
}

function spin() {
    i--;
    document.getElementById('credit').innerHTML = i;

    if (i > 0) {
        let a1 = Math.floor(Math.random() * 8) + 1;
        imgfruit1.setAttribute("src", "/IMG/fruit" + a1 + ".png");
        credit--;

        let a2 = Math.floor(Math.random() * 8 + 1);
        imgfruit2.setAttribute("src", "/IMG/fruit" + a2 + ".png");
        credit--;

        let a3 = Math.floor(Math.random() * 8) + 1;
        imgfruit3.setAttribute("src", "/IMG/fruit" + a3 + ".png");
        credit--;

        btnCollectWinnings.disabled = false;

        //this if statmenst says if pic 1 and 2 are = then + 5 to winnings


        if (a3 == a2 || a1 == a2) {
            x = x + 5;
            document.getElementById('Winnings').innerHTML = x;
        }  if (a1==a2&&a2==a3)
            x = x + 10;
        document.getElementById('Winnings').innerHTML = x;
    }

}
function collectwinnings() {
    if (i > 0){
    alert("Winnings have been collected. Game reset");
    window.location.reload();
    }

}
