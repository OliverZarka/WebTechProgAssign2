const eticket = document.getElementById("eticket");
const cfbo = document.getElementById("cfbo");
const Po = document.getElementById("Po");
const submit = document.getElementById("submit");
const tickets = document.getElementById("tickets");
const qpeople = document.getElementById("nopeople");


//eventlisteners
eticket.addEventListener("click",calc );
cfbo.addEventListener("click",calc );
Po.addEventListener("click", calc);
tickets.addEventListener("click", add);
qpeople.addEventListener("click", add);
submit.addEventListener("click", confnpay);

function add()
		{
			var tickets = document.getElementById('tickets').value;
			var nopeople = document.getElementById('nopeople').value;
			var result = tickets * nopeople;
			document.getElementById('price').innerHTML = ("£" + result.toFixed(2));
			
			if(nopeople == 6 || nopeople == 7|| nopeople == 8|| nopeople == 9){
				document.getElementById('discount').innerHTML = ("10% discount at checkout")
				var result2 = result - [tickets * nopeople] * 10 / 100;
				document.getElementById('rs2').innerHTML =("£" + result2.toFixed(2));
			}
			else if (nopeople == 10 || nopeople > 10 ){
				document.getElementById('discount').innerHTML = ("15% discount at checkout")
						var result2 = result - [tickets * nopeople] / 100 * 15;
							document.getElementById('rs2').innerHTML =("£" + result2.toFixed(2));
			}
			


		}
		
    

function calc(){
	

	if(document.getElementById('eticket').checked){
		document.getElementById('r3').innerHTML = ("delivery cost");
		document.getElementById('r1').innerHTML = ("£"+ eticket.value);

	}
	else if(document.getElementById('cfbo').checked){
		document.getElementById('r3').innerHTML = ("delivery cost");
		document.getElementById('r1').innerHTML = ("£"+ cfbo.value);
	}
	else if(document.getElementById('Po').checked){
		document.getElementById('r3').innerHTML = ("delivery cost");
		document.getElementById('r1').innerHTML = ("£"+ Po.value);
	}
	}
	

	